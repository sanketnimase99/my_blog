﻿Numbers n1 = new Numbers();
n1.accept();
n1.sum();
n1.sorting();
n1.EvenAndOdd();
n1.avg();
n1.LowAndHigh();