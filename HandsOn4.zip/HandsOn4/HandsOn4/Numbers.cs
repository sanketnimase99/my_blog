﻿ class Numbers
    {
    int [] array = new int[10];
     public void accept()
     {
        Console.WriteLine("Enter the array Elements : ");
        for (int i = 0;i<10;i++)
        {
            array[i] = Convert.ToInt32(Console.ReadLine());

        }
     }
    public void sum()
    {
        int add = 0;
        for (int i = 0; i < 10; i++)
        {
            add += array[i];

        }
        Console.WriteLine($"The sum is : {add}");
    }
     public void sorting()
    {
        Array.Reverse(array);
        Console.WriteLine("Numbers in Descending order are : ");
        foreach(int val in array)
            Console.Write($"{val}  ");
    }
    public void LowAndHigh()
    {
        int low=0, high=0;
        for (int i = 0;i<10;i++)
        {
            if(array[i]<low)
            {
                low = array[i];
            }
            if(array[i]>high)
                high=array[i];
        }
        Console.WriteLine($"The highest no is : {high}");
        Console.WriteLine($"The lowest no is : { low}");
    }
    public void avg()
    {
        int add = 0;
        for (int i = 0; i < 10; i++)
        {
            add += array[i];

        }
        Console.WriteLine($"The avg is : {add/10}");
    }
    public void EvenAndOdd()
    {
        int even = 0, odd = 0;
        for (int i = 0; i < 10; i++)
        {
            if (array[i] % 2 == 0)
            {
                even++;
            }
            else
                odd++;
        }
        Console.WriteLine($"The Even no's are : {even}");
        Console.WriteLine($"The Odd no's are : {odd}");
    }
}
