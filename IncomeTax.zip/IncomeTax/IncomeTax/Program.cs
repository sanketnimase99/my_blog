﻿using System;

namespace IncomeTax
{
    class Program
    {
        static void Main(string[] args)
        {
            double income;
            double incomeTax = 0;
            char choice;
            do
            {
                Console.WriteLine("Enter Your Income : ");
                income= Convert.ToDouble(Console.ReadLine());
                if (income >= 0 && income <= 250000)
                {
                    incomeTax = 0;
                }   
                else if(income>250000 && income<=500000)
                { 
                    incomeTax = (5 / 100) * income;

                }
                else if (income > 500000 && income <= 750000)
                {
                    incomeTax = (10 / 100) * income;

                }
                else if (income > 750000 && income <= 1000000)
                {
                    incomeTax = (15 / 100) * income;

                }
                else if (income > 1000000 && income <= 1250000)
                {
                    incomeTax = (20 / 100) * income;

                }
                else if (income > 1250000 && income <= 1500000)
                {
                    incomeTax = (25 / 100) * income;

                }
                else 
                {
                    incomeTax = (30 / 100) * income;
                }
                Console.WriteLine("Income tax is : {0}", incomeTax);
                Console.WriteLine("Do you want to Continue?(y/n)");
                choice = Console.ReadLine()[0];
            } while (choice == 'y');
        }
    }
}
